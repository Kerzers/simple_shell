#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include "simpleShell.h"

/**
 * executeOnce - executes commands using execve
 * @cmdMain: the string that contains the command entered non-interactively
 * @av: ...
 * @ln: ...
 * @env: ...
 */

void executeOnce(char *cmdMain, char **env, char **av, int ln)
{
	int s, status;
	char **a, *cmd;
	pid_t pid;

		s = sizer(cmdMain);
		if (_strcmp("exit\n", cmdMain) == 1)
                        exit(1);
		a = malloc((s + 1) * sizeof(char *));
		if (a == NULL)
		{
			perror("Error ");
			exit(1);
		}
		tokenizer(a, cmdMain);
		if (a[0] == NULL)
			return;
		cmd = searchCmd(a[0]);
		if (cmd != NULL)
		{
			pid = fork();
			if (pid == 0)
			{
				a[0] = cmd;
				/*Execution time*/
				if (execve(a[0], a, env) == -1)
				{
					perror("Error in non-int execution ");
				}
				/*free(a);*/
			}
			else
			{
				wait(&status);
				fflush(stdout);
				free(a);
			}
		}
		else
		{
			wrF(av[0], a[0], ln);
		}
}

/**
 * execInteractive - takes a string that has been capturede from user entry
 * and extracts the command and the arguments for that command
 * @env: ...
 */

void execInteractive(char **env)
{
	int status, s = 0;
	char *buffer = NULL;
	size_t size = 0;
	pid_t pid;
	char **a;

	while (1)
	{
		writerFunct("#cisfun$ ");
		if (getline(&buffer, &size, stdin) == -1)
		{
			writerFunct("exit\n");
			exit(1);
		}
		if (_strcmp("exit\n", buffer) == 1)
			exit(1);
		s = sizer(buffer);
		a = malloc((s + 1) * sizeof(char *));
		tokenizer(a, buffer);
		a[0] = searchCmd(a[0]);
		if (a[0] != NULL)
		{
			pid = fork();
			if (pid == 0)
			{
				if (execve(a[0], a, env) == -1)
				{
					perror("Error in cmd execution ");
					exit(1);
				}
			}
			else
			{wait(&status);
				fflush(stdout);
				free(a);
				if (!WIFEXITED(status))
				{
					exit(1);
				}
			}
		}
	}
}

/**
 * sizer - function that returns the number of tokens generated
 * @str: the string to be brokwn down
 * Return: the number of tokens generated
 */

int sizer(char *str)
{
	int n = 0;
	char *token = NULL, *tmp;

	if (str == NULL)
		return (-1);
	tmp = malloc(myStrLen(str) + 1);
	if (tmp == NULL)
	{
		perror("Err allocating memory for tmp");
		return (-1);
	}
	_strcpy(tmp, str);
	token = strtok(tmp, " \t\n");
	while (token != NULL)
	{
		n++;
		token = strtok(NULL, " \t\n");
	}
	free(tmp);
	return (n);
}

/**
 * tokenizer -  function that breaks up a string using strtok
 * @buffer: ...
 * @a: ...
 */

void tokenizer(char **a, char *buffer)
{
	char *token;
	int i = 0;

	token = strtok(buffer, " \t\n:");
	if (token == NULL)
		a[1] = NULL;
	else
	{
	while (token != NULL)
	{
		a[i] = token;
		token = strtok(NULL, " \t\n:");
		i++;
	}
	a[i] = NULL;
	}
}

/**
 * writerFunct - writes like printf
 * @str: to be written to stdout
 */

void writerFunct(char *str)
{
	char *str1 = str;

	while (*str1)
	{
		write(1, &(*str1), 1);
		str1++;
	}
}
