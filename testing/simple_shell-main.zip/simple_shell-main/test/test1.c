#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

int main(void)
{
	char *entry = NULL, *token = NULL;
	size_t n = 0;
	char **arg = malloc(5 * sizeof(char *));
	int i = 0;

	printf("$$ ");
	if (getline(&entry, &n, stdin) == -1)
	{
		printf("---\n");
	}

	token = strtok(entry, " \t\n");
	while (token != NULL)
	{
		printf("%s\n", token);
		arg[i] = token;
		token = strtok(NULL, " \t\n");
		i++;
	}
	arg[i] = NULL;

	if (execve(arg[0], arg, NULL) == -1)
	{
		printf("++++\n");
	}

	return(0);
}
