#ifndef SIMPLESHELL_H
#define SIMPLESHELL_H
void executeOnce(char *cmdMain, char  **env, char **av, int ln);
void execInteractive(char **env);
char *_strcat(char *a, char *b);
void wrF(char *str, char *strB, int u);
void wrD(int u);
char *_strcpy(char *a, char *b);
int myStrLen(char *str);
void writerFunct(char *str);
char *searchCmd(char *cmdPath);
char *_getenv(const char *str);
int _strcmp(const char *s1, char *s2);
int sizer(char *s);
char *tempMaker(char *str);
void tokenizer(char **a, char *buffer);

extern char **environ;

#endif
