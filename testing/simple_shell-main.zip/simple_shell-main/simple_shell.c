#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include <stdlib.h>
#include "simpleShell.h"

/**
 * main - simple shell main function
 * @ac: Number of arguments
 * @av: An array of pointers
 * @envp:...
 * Return: 0 on success
 */

int main(int ac, char **av, char **envp)
{
	char *buff = NULL, *str;
	size_t n = 0;
	ssize_t g = 0;
	int i = 1, ln = 0;

	(void)ac;
	(void)av;

	if (!isatty(fileno(stdin)))
	{
		while ((g = getline(&buff, &n, stdin)) > 0)
		{
			ln++;
			executeOnce(buff, envp, av, ln);
		}
	}
	else
	{
		if (ac > 1)
		{
			if (ac == 2)
				executeOnce(av[1], envp, av, ln);
			else
			{

			str = av[i];
			while (av[i] != NULL)
			{
				_strcat(str, " ");
				_strcat(str, av[i]);
				i++;
			}
			executeOnce(str, envp, av, ln);
			}
		}
		execInteractive(envp);
	}
	free(buff);
	return (0);
}
